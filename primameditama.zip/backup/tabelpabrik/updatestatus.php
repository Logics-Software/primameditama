<?php

include_once '../../config/Database.php';
include_once '../../models/TabelPabrik.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate FileCustomer object
$tabelpabrik = new TabelPabrik($db);

// Get kodepabrik from query string if present
$kodepabrik = isset($_GET['kodepabrik']) ? $_GET['kodepabrik'] : null;

// Get customer(s)
$response = $tabelpabrik->updatestatus($kodepabrik);

// Output JSON response
echo json_encode($response);