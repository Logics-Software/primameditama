<?php
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: DELETE');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization,X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/FileSalesman.php';
  
  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $filesalesman = new FileSalesman($db);

  // Get raw posted data
  $data = json_decode(file_get_contents("php://input"));

  // Set ID to update
  $filesalesman->kodesalesman = $data->kodesalesman;
  
  // Delete post
  if($filesalesman->delete()) {
    echo json_encode(
      array('message' => 'Master Salesman deleted')
    );
  } else {
    echo json_encode(
      array('message' => 'Master Salesman not deleted')
    );
  }
