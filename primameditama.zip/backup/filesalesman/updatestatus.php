<?php

include_once '../../config/Database.php';
include_once '../../models/FileSalesman.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Instantiate DB & connect
$database = new Database();
$db = $database->connect();

// Instantiate FileCustomer object
$filesalesman = new FileSalesman($db);

// Get kodecustomer from query string if present
$kodesalesman = isset($_GET['kodesalesman']) ? $_GET['kodesalesman'] : null;

// Get customer(s)
$response = $filesalesman->updatestatus($kodesalesman);

// Output JSON response
echo json_encode($response);