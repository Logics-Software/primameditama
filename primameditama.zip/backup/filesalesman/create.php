<?php
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization,X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/FileSalesman.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $filesalesman = new FileSalesman($db);

  // Get raw posted data
  $data = json_decode(file_get_contents("php://input"));

  $filesalesman->kodesalesman = $data->kodesalesman;
  $filesalesman->namasalesman = $data->namasalesman;
  $filesalesman->alamatsalesman = $data->alamatsalesman;
  $filesalesman->notelepon = $data->notelepon;
  $filesalesman->kodearea = $data->kodearea;
  $filesalesman->userid = $data->userid;
  $filesalesman->status = $data->status;

  // Create Message
  if($filesalesman->create()) {
    $response=array(
      'status' => 200,
      'message' =>'Data Salesman Created!'
    );
  } else {
    $response=array(
      'status' => 400,
      'message' =>'Data Salesman Not Created!'
    );
  }
  header('Content-Type: application/json');
  echo json_encode($response);